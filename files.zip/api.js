// Simple Express API to proxy Gemini for sentiment and summary analysis

// Install these dependencies if needed: npm install express cors body-parser node-fetch
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY; // Set in your environment variables for security

const app = express();
app.use(cors());
app.use(bodyParser.json());

const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${GEMINI_API_KEY}`;

app.post('/sentiment', async (req, res) => {
    const textToAnalyze = req.body.text;
    const systemPrompt = `You are a sentiment analysis API. Your sole purpose is to analyze the sentiment of the user's text.
You MUST respond in JSON format ONLY. Do not add any conversational text or markdown.
The JSON must have this exact schema:
{
  "sentiment": "[Positive/Negative/Neutral]",
  "score": [number between -1.0 and 1.0],
  "explanation": "[A brief, one-sentence explanation for your reasoning]"
}`;
    const jsonSchema = {
        "type": "OBJECT",
        "properties": {
            "sentiment": { "type": "STRING" },
            "score": { "type": "NUMBER" },
            "explanation": { "type": "STRING" }
        },
        "required": ["sentiment", "score", "explanation"]
    };
    const payload = {
        contents: [{ parts: [{ text: textToAnalyze }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            responseMimeType: "application/json",
            responseSchema: jsonSchema,
            temperature: 0.1,
            maxOutputTokens: 512
        }
    };

    try {
        const response = await fetch(GEMINI_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        const candidate = result.candidates?.[0];
        const data = candidate && candidate.content?.parts?.[0]?.text ? JSON.parse(candidate.content.parts[0].text) : null;
        if (data) {
            res.json(data);
        } else {
            res.status(500).json({ error: 'Gemini API response error', api: result });
        }
    } catch (error) {
        res.status(500).json({ error: 'Internal error', detail: error.toString() });
    }
});

app.post('/summary', async (req, res) => {
    const textToAnalyze = req.body.text;
    const systemPrompt = `You are a text summarization service. Your sole purpose is to provide a concise, high-quality summary of the user's text.
Respond with the summary directly in plain text. Do not add any conversational text, pleasantries, or markdown formatting.
Begin the summary immediately.`;
    const payload = {
        contents: [{ parts: [{ text: textToAnalyze }] }],
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
            temperature: 0.3,
            topP: 0.9,
            maxOutputTokens: 512
        }
    };
    try {
        const response = await fetch(GEMINI_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await response.json();
        const candidate = result.candidates?.[0];
        const summary = candidate && candidate.content?.parts?.[0]?.text ? candidate.content.parts[0].text : null;
        if (summary) {
            res.json({ summary });
        } else {
            res.status(500).json({ error: 'Gemini API response error', api: result });
        }
    } catch (error) {
        res.status(500).json({ error: 'Internal error', detail: error.toString() });
    }
});

app.listen(PORT, () => {
    console.log(`API server running at http://localhost:${PORT}`);
});